# Testing

You can compile and run the tests yourself by running:

```
make
build/hmm_test_c
build/hmm_test_c_no_sse
build/hmm_test_cpp
build/hmm_test_cpp_no_sse
```
